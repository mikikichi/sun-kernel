qemu-system-i386 -cdrom sun.iso
