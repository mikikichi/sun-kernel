./build.sh
sudo ./mkiso.sh
./run.sh
